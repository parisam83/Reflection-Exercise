package ir.sharif.math.ap2023.hw7.models.sample6;

import ir.sharif.math.ap2023.hw7.SetValue;

public class B {
    @SetValue(path = "../s")
    int t;
}
