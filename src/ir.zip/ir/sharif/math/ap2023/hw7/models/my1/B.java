package ir.sharif.math.ap2023.hw7.models.my1;

import java.util.Arrays;

public class B {
    private String[] str;

    @Override
    public String toString() {
        return "B{" +
                "str=" + Arrays.toString(str) +
                '}';
    }
}
