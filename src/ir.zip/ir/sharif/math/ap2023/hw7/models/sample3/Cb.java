package ir.sharif.math.ap2023.hw7.models.sample3;

public class Cb extends C {
    int h;

    @Override
    public String toString() {
        return "Cb{" + "h=" + h + ", a=" + a + ", b=" + b + '}';
    }
}
