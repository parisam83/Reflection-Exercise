package ir.sharif.math.ap2023.hw7.models.tooDarTooSample;

public class B {
    A a;
}
