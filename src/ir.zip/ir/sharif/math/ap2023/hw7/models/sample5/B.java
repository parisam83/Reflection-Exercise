package ir.sharif.math.ap2023.hw7.models.sample5;

public class B {
    int x;
}
