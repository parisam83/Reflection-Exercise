package ir.sharif.math.ap2023.hw7.models.my1;

import java.util.Arrays;

public class A {
    private int[][] bs;

    @Override
    public String toString() {
        return "A{" +
                "bs=" + Arrays.deepToString(bs) +
                '}';
    }
}
