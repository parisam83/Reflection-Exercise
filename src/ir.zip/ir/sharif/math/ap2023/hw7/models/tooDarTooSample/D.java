package ir.sharif.math.ap2023.hw7.models.tooDarTooSample;

import ir.sharif.math.ap2023.hw7.Name;
import ir.sharif.math.ap2023.hw7.SetValue;

public class D {
    @Name(name = "cc")
    C c;

    @SetValue(path = "")
    D d;

    @Name(name = "DDDD")
    int DDD = 20;
}
