package ir.sharif.math.ap2023.hw7.models.my3;

import java.util.Arrays;

public class A {
    private B[][] bs;

    @Override
    public String toString() {
        return "A{" +
                "bs=" + Arrays.deepToString(bs) +
                '}';
    }
}
