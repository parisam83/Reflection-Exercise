package ir.sharif.math.ap2023.hw7.models.my5;

public class C {
    private B b;
    private int q;

    @Override
    public String toString() {
        return "C{" +
                "b=" + b +
                ", q=" + q +
                '}';
    }
}
