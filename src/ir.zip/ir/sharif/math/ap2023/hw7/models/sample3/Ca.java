package ir.sharif.math.ap2023.hw7.models.sample3;

public class Ca extends C {
    int c;

    @Override
    public String toString() {
        return "Ca{" + "c=" + c + ", a=" + a + ", b=" + b + '}';
    }
}
