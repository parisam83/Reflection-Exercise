package ir.sharif.math.ap2023.hw7.models.sample6;

import ir.sharif.math.ap2023.hw7.Name;

public class A {
    B b;
    @Name(name = "s")
    int i2;
}
