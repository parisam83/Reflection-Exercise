package ir.sharif.math.ap2023.hw7.models.basicSample;

public class Father {
    private int var1;
    protected int var2;
    int var3;
    public int var4;

    public final int var5;
    public static int var6;


    protected Father() {
        var5 = 5;
    }

    public int getVar1() {
        return var1;
    }
}
