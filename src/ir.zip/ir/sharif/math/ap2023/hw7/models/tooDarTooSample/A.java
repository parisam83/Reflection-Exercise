package ir.sharif.math.ap2023.hw7.models.tooDarTooSample;

import ir.sharif.math.ap2023.hw7.SetValue;

public class A {
    int a = 0;

    @SetValue(path = "../../../DDDD")
    int INT;
}
