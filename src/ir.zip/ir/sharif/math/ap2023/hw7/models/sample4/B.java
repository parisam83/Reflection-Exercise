package ir.sharif.math.ap2023.hw7.models.sample4;

public class B {
    int x;
}
